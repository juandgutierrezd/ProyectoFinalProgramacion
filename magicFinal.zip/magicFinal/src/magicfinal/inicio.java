
package magicfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author duran
 */
public class inicio extends JFrame implements MouseListener{
    JPanel panelInicio;
    JButton botonIniciar, botonInstrucciones, botonCreditos;
    ImageIcon fondo;
    JLabel fondoo;
    
    
    
    
    public inicio() {
        this.setTitle("TypingManiac");
        initComponents();
    }
    
    public void initComponents(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //----> panel
        fondo = new ImageIcon("pantallainicial.jpg");
        panelInicio = new JPanel();
        panelInicio.setLayout(null);
               panelInicio.setBackground(Color.red);
               panelInicio.setBounds(0, 0, 300, 400);
               this.getContentPane().add(panelInicio);
               
               //JLabel fondo
               fondoo = new JLabel();
               fondoo.setIcon(fondo);
               fondoo.setBounds(0, 0, 300, 400);
               panelInicio.add(fondoo);
               //-----> botones
               botonIniciar = new JButton("INICIAR");
               botonIniciar.setBounds(40, 60, 200, 40);
               botonIniciar.setBackground(Color.black);
               botonIniciar.setForeground(Color.yellow);
               botonIniciar.setFont(new Font("Arial", Font.PLAIN, 20));
               fondoo.add(botonIniciar);
               
               
               //--------------->boton instrucciones
               botonInstrucciones = new JButton("INSTRUCCIONES");
               botonInstrucciones.setBounds(40, 160, 200, 40);
               botonInstrucciones.setBackground(Color.black);
               botonInstrucciones.setForeground(Color.yellow);
               botonInstrucciones.setFont(new Font("Arial", Font.PLAIN, 20));
               fondoo.add(botonInstrucciones);
               //-------------------> boton creditos
               botonCreditos = new JButton("CREDITOS");
               botonCreditos.setBounds(40, 260, 200, 40);
               botonCreditos.setBackground(Color.black);
               botonCreditos.setForeground(Color.yellow);
               botonCreditos.setFont(new Font("Arial", Font.PLAIN, 20));
               fondoo.add(botonCreditos);
               
               //agregando listener a los botones
               botonIniciar.addMouseListener(this);
               botonInstrucciones.addMouseListener(this);
               botonCreditos.addMouseListener(this);
               
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == botonIniciar){
            cuentaLogin login = new cuentaLogin();
            login.setBounds(0, 0, 300, 300);
            login.setVisible(true);
            login.setResizable(false);
            login.setLocationRelativeTo(null);
            //cerramos pantalla actual 
            this.setVisible(false);
            
        }else if(e.getSource() == botonInstrucciones){
            JOptionPane.showMessageDialog(null,"----Instrucciones---"+"\n" 
                    + "                               BIENVENIDO A MAGICTYPING."+"\n"
                    +" El juego consiste en saber que tan veloz eres tipeando palabras, "+"\n"
                    +" contiene tres niveles que ira variando su dificultad, al comenzar"+"\n"
                    +" el juego deberás estar atento con la palabra que cae y escribir la "+"\n"
                    +" palabra en el recuadro que se te presenta en la pantalla antes de"+"\n"
                    +" que termine su recorrido, una vez escrita tendrás que presionar la"+"\n"
                    +" tecla ENTER para ver si la palabra es correcta o incorrecta."+"\n"
                    +" \n\n"
                    +" Para pasar de nivel tendrás que tipear una cierta cantidad de"+"\n"
                    +" palabras, si no alcanzas ese mínimo de palabras, perderás el"+"\n"
                    +" juego."
                    +" \n\n"
                    +" Para ayudar un poco en el juego te proporcionamos dos bonos, el"+"\n"
                    +" primer bono consiste en que deberás escribir la palabra \"pare\" y"+"\n"
                    +" las palabras que se encuentren cayendo se detendrán por un"+"\n"
                    +" cierto tiempo y que deberás utilizarlo para tipear las palabras en"+"\n"
                    +" la pantalla. El segundo bono variara del nivel en que te"+"\n"
                    +" encuentres consiste en una palabra diferente que te"+"\n"
                    +" proporcionara diferentes ayudas."+"\n");
      
        }else if(e.getSource() == botonCreditos){
            JOptionPane.showMessageDialog(null,"----CREDITOS---"+"\n" 
                    + "JUEGO REALIZADO POR ."+"\n"
                    +" NOMBRE: LUIS ANDRES DURAN MONCADA "+"\n"
                    +" CEDULA: V-27893702"+"\n"
                    +" NOMBRE: JUAN DIEGO GUTIERREZ DUARTE... "+"\n"
                    +"CEDULA: V 27.675.445"+"\n");
            
        }
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
    
    
    
    
    
}
