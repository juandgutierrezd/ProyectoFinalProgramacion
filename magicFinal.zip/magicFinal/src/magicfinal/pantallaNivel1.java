
package magicfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.SwingConstants;


/**
 *
 * @author duran
 */
public class pantallaNivel1 extends JFrame implements KeyListener{
    JPanel panelJuego1, panelBonus,panelPalabrasCayendo[] = new JPanel[10], panelFondoBonus;
    JLabel nameScore,labeLInicio,fondoo,personajee,bonusStop,bonusDisponibles,bonusDisponibles1;
    JLabel labelPalabras[] = new JLabel[10];
    JTextField texto,textoScore;
    String palabraActual;
    ImageIcon fondo,personaje;
    Icon icono,icono1;
 
    boolean isBonus = false,isActive = false,startGame = false,ocupado = false,isBonusCorrect = false;
    int contadorPalabra = 0, contadorPalabrasCorrectas = 0,arreglo[] = new int[10],v = 0,velocidad = 1000,parar = 0, tiempo = 0, i=4;
    String[] palabras ={"papichulo","culamen","sapo","loco","videos","zapato","numeros","espanglish","tuit","pc"};
    Sonido sonido = new Sonido();
    Sonido sonido2 = new Sonido();
    Sonido sonido3 = new Sonido();
    Sonido sonido4 = new Sonido();
    Sonido sonido5 = new Sonido();
    
    public pantallaNivel1() {
        //setDefault para cerrar la ventana cuando se unda la x
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        personaje = new ImageIcon("jugadorPrimerNivel.PNG");
        //creamos  el panel de fondo
        panelJuego1 = new JPanel();
        panelJuego1.setLayout(null);
        panelJuego1.setBounds(0, 0, 1000,900);
        panelJuego1.setOpaque(false);
        this.getContentPane().add(panelJuego1);
        
        fondoo = new JLabel();
        
        fondoo.setOpaque(false);
        fondoo.setBounds(0,0,920,700);
        panelJuego1.add(fondoo);
        //label inicio contador de cuenta regresiva 
        labeLInicio = new JLabel();
        labeLInicio.setBounds(420, 300, 200, 100);
        labeLInicio.setFont(new Font("Serif", Font.PLAIN, 50));
        fondoo.add(labeLInicio);
        sonido2.ReproducirSonido("sonidos/pacma.wav");
        timerContador.start();
        // System.out.print("estara activo?"+ startGame);
    }
    
    
    //metodo para terminar de iniciar los componentes
    public void initComponents(){
        generarNumeroAleatorios(10,10);
        fondo = new ImageIcon("fondo1.jpg");
        personaje = new ImageIcon("jugadorPrimerNivel.PNG");
        //bonus points
        bonusStop= new JLabel("parangutirimicuaro");
        bonusStop.setForeground(Color.orange);
        bonusStop.setBounds(190, 10, 120, 20);
        bonusStop.setVisible(false);
        fondoo.add(bonusStop);
        //panel de fondo del bonus
        panelFondoBonus = new JPanel();
        panelFondoBonus.setBounds(190, 10, 120, 20);
        panelFondoBonus.setVisible(false);
        panelFondoBonus.setBackground(Color.black);
        fondoo.add(panelFondoBonus);
        panelJuego1 = new JPanel();
        panelJuego1.setLayout(null);
        icono = new ImageIcon(fondo.getImage().getScaledInstance(this.getWidth(),this.getHeight(),Image.SCALE_DEFAULT));
        panelJuego1.setBackground(Color.MAGENTA);
        
        this.getContentPane().add(panelJuego1);
        
        //Label fondo
        fondoo = new JLabel();
        fondoo.setIcon(icono);
        //fondoo.setBounds(0,0,1000,900);
        fondoo.setBounds(0,0,this.getWidth(),this.getHeight());
        panelJuego1.add(fondoo);
        
        //Label personaje
        personajee = new JLabel();
         icono1 = new ImageIcon(personaje.getImage().getScaledInstance(320,300,Image.SCALE_SMOOTH));
        personajee.setIcon(icono1);
        personajee.setBounds(320,370,500,300);
        fondoo.add(personajee);
        //el Scoreee
        nameScore = new JLabel("Score: ");
        nameScore.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        nameScore.setBounds(850, 400, 50, 20);
        fondoo.add(nameScore);
        //ubicaicon del texrField donde se mostraran los puntos
        textoScore = new JTextField();
        textoScore.setBounds(850, 420, 50, 20);
        textoScore.setEditable(false);
        textoScore.setBackground(Color.LIGHT_GRAY);
        fondoo.add(textoScore);
        //cuenta regresiva
        labeLInicio = new JLabel();
        labeLInicio.setBounds(200, 200, 200, 100);
        labeLInicio.setFont(new Font("Serif", Font.PLAIN, 50));
        fondoo.add(labeLInicio);
        //recorrido que llenara el panel y los acomodara en las posiciones, tambien acomoda el label de as pantalla
        for(int i = 0 ;i<labelPalabras.length;i++){
            panelPalabrasCayendo[i] = new JPanel();
            panelPalabrasCayendo[i].setBackground(Color.gray);
            panelPalabrasCayendo[i].setBounds(i*90, 10, 80, 20);
            panelPalabrasCayendo[i].setVisible(false);
            labelPalabras[i] = new JLabel(palabras[i]);
            labelPalabras[i].setBounds(i*90, 10, 80, 20);
            labelPalabras[i].setForeground(Color.white);
            labelPalabras[i].setVisible(false);
            labelPalabras[i].setFont(new Font("Times New Roman", Font.PLAIN, 17));
            labelPalabras[i].setHorizontalAlignment(SwingConstants.CENTER);
            fondoo.add(labelPalabras[i]);
            
            fondoo.add(panelPalabrasCayendo[i]);
            
        }
        texto = new JTextField();
        texto.setBounds(400, 640, 100, 20);
        fondoo.add(texto);

        texto.addKeyListener(this);

        //bonus disponibles
        panelBonus = new JPanel();
        panelBonus.setBounds(850, 300, 60, 50);
        panelBonus.setBackground(Color.LIGHT_GRAY);
        fondoo.add(panelBonus);
        bonusDisponibles = new JLabel("BONUS :");
        bonusDisponibles.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        bonusDisponibles.setBounds(850, 300, 50, 20);
        panelBonus.add(bonusDisponibles);
        //bonus
        bonusDisponibles1 = new JLabel("pare");
        bonusDisponibles1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        bonusDisponibles1.setBounds(850, 320, 50, 20);
       
        panelBonus.add(bonusDisponibles1);
        //comienza el timer para que caigan las palabras
        timer.start();
    }
    
  
    Timer timer = new Timer(velocidad,
            new ActionListener(){
        
                @Override
                public void actionPerformed(ActionEvent e) {
                    
                    //parar para la condicion del bonus
                    if( parar == 0) {
                            //se recorrera este if mientras que todavian hayas palabras por bajar
                         if(v != 10 ){
                            panelPalabrasCayendo[arreglo[v]].setVisible(true);
                            labelPalabras[arreglo[v]].setVisible(true);
                            panelPalabrasCayendo[arreglo[v]].setLocation(panelPalabrasCayendo[arreglo[v]].getX(), panelPalabrasCayendo[arreglo[v]].getY()+50);
                            labelPalabras[arreglo[v]].setLocation(labelPalabras[arreglo[v]].getX(), labelPalabras[arreglo[v]].getY()+50);
                            // System.out.println("y0: "+labelPalabras[arreglo[v]].getY());
                            // System.out.println("y "+(v+1)+"::"+labelPalabras[arreglo[v]].getY());                   
                            palabraActual = labelPalabras[arreglo[v]].getText().toString();                             
                                if(labelPalabras[arreglo[v]].getY() == 610 || isActive ==true || panelPalabrasCayendo[arreglo[v]].getY() == 610){
                                   System.out.println("troleo hermano");  
                                   panelPalabrasCayendo[arreglo[v]].setVisible(false);
                                   labelPalabras[arreglo[v]].setVisible(false);
                                   v ++; 
                                   isActive = false;
                                }   
                                if(v ==5){
                                isBonus=true;
  
                            }
                        }

                        if(v ==10){
                            terminar();
                            
                        }
                        if(isBonus ==true){
                            panelFondoBonus.setVisible(true);
                            bonusStop.setVisible(true);
                            panelFondoBonus.setLocation(panelFondoBonus.getX(),panelFondoBonus.getY()+50);
                            bonusStop.setLocation(bonusStop.getX(),bonusStop.getY()+50);
                                
                                if(bonusStop.getY()==610 || isBonusCorrect==true ||panelFondoBonus.getY()==610){
                                    bonusStop.setVisible(false);
                                    panelFondoBonus.setVisible(false);
                                    isBonus=false; 
                                }
                    }
                        
                        //CONDICION IMPORTANTE PARA QUE SE PUEDA CUMPLIR EL STOP DEL JUEGO
                    }else {
                        tiempo++;
                        if(tiempo == 5){
                            parar = 0;
                            ocupado = false;
                        }
                    }
                }  

                    
            });
    
    
    //cuenta regresiva , la presentacion del primer nivel
   Timer timerContador = new Timer(1000,
            new ActionListener(){
        
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Tu Codigo
                   
                    
                    if(i!=0){
                        labeLInicio.setText(String.valueOf(i-1));
                        i--;
                        
                    }
                    
                    if(i==0){
                         labeLInicio.setText("READY");
                       i--;
                     
                    }
                   
                    if(i==-2){
                        labeLInicio.setVisible(false);
                        startGame =true;
                        terminarContador();
                        componenetes(startGame);
                        sonido.ReproducirSonido("sonidos/mario.wav");
                        
                    }
                    
                }

       
            });

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //System.out.println("presiono la tecla: "+e.getKeyCode());
        
        
        switch(e.getKeyCode()){
            case KeyEvent.VK_ENTER:{
                //caso deque sea igaul palabra
                    if(texto.getText().compareTo("pare") == 0  && ocupado == false){
                        sonido5.ReproducirSonido("sonidos/hongo.wav");
                        System.out.println("para el proceso");
                        texto.setText("");
                        bonusDisponibles1.setVisible(false);
                        parar = 1;
                        velocidad = 1000;
                        tiempo = 0;
                        ocupado = true;
                    }else if(texto.getText().equalsIgnoreCase(palabraActual)){
                       
                            CorrectWords(); 
                       

                    }else if(texto.getText().equalsIgnoreCase("parangutirimicuaro")){
                      JOptionPane.showMessageDialog(null, "HAZ OBTENIDO UN BONUS DE 500 PTS :)");
                      contadorPalabra=contadorPalabra+500;
                      texto.setText("");
                      isBonusCorrect = true;
                  }else{
                       IncorrectWords();
                    }
                break;
            }
        }              
                
            
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    
    //VALIDARA LA PALABRA QUE CAE CON LA PALBRAA QUE SE ESCRIBIO EN EL TEXTFIELD
    public void CorrectWords(){
        //System.out.println("la palabra es correcta");
        sonido3.ReproducirSonido("sonidos/moneda.wav");
        texto.setText("");
        contadorPalabra = contadorPalabra+50;
        textoScore.setText(String.valueOf(contadorPalabra));
        isActive = true;
        contadorPalabrasCorrectas++;
    }
    public void IncorrectWords(){
        sonido4.ReproducirSonido("sonidos/tubo.wav");
        texto.setText("");
        contadorPalabra = contadorPalabra-20;
        textoScore.setText(String.valueOf(contadorPalabra));
       // System.out.println("perdio puntos SAPO");
    }
    //generamos numeros aleatorios
    public void generarNumeroAleatorios(int cantidad,int rango){
        int i = 0;
                     
                    //del uno al 10 quiero que me genere
                     
                     arreglo[i] = (int)(Math.random()*rango);
                     for(i=1;i<cantidad;i++){
                        arreglo[i] = (int)(Math.random()*rango);
                        for (int j = 0; j < i; j++) {
                            if(arreglo[i] == arreglo[j]){
                                i--;
                            }
                        }
                    }
                     for (int j = 0; j < arreglo.length; j++) {
                         System.out.println("aleatorio"+ arreglo[j]);       
                    }    
    }
    //detonador del timer
     public void terminar(){
        timer.stop();
        if(textoScore.getText().toString().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(null, "puntaje total: 0 ");
        }else{
            JOptionPane.showMessageDialog(null, "puntaje total: "+ textoScore.getText().toString());  
        }
       
                        if(contadorPalabrasCorrectas>=6){
                           JOptionPane.showMessageDialog(null, "HAZ PASADO AL  NIVEL 2 ,PRESIONA ACEPTAR");
                            pantallaNivel2  nivel2 = new pantallaNivel2();
                            this.setVisible(false);
                            nivel2.setVisible(true);
                            nivel2.setBounds(0, 0, 920, 700);
                            nivel2.setLocationRelativeTo(null);
                            nivel2.setResizable(false);
                                
                            try {
                              BufferedWriter bufer = new BufferedWriter (new FileWriter ("puntaje.txt",true));
                              bufer.write(textoScore.getText());
                              bufer.close();
                             
                             }catch (IOException e1){
                            JOptionPane.showMessageDialog(null,"Se ha presentado un problema en el registro","Error",2);
                            };
                            
                            
                            
                        }else{
                            sonido3.ReproducirSonido("sonidos/perdio.wav");
                            JOptionPane.showMessageDialog(null, "no haz alcanzado el limite de palabras,vuevle a intentarlo");
                            System.exit(0);
                        }
    }
     //PARA LA CUENTA REGRESIVA
     public void terminarContador(){
         timerContador.stop();
     }
     //SE INICIALIZARA LOS COMPONENTES DESPUES DE QUE SE ACABE LA CUENTA DE REGRESIVA PARA EVITAR BUGS
     public void componenetes(boolean active){
         if(active == true){
             System.out.println("es verdadero esta");
          
             initComponents();
                
             
         }
         
     }

}
