
package magicfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author duran
 */
public class LoginNuevoUsuario extends JFrame implements MouseListener{
    JPanel panelNuevoUsuario;
    JLabel labelTitulo,labelNombre, labelSexo,labelAsterisco;
    JTextField textNombre;
    JRadioButton radioSexoFemenino,radioSexoMasculino;
    ButtonGroup grupo1 = new ButtonGroup();
    JButton botonRegistrar;
    ImageIcon fondo;
    JLabel fondoo;
    
    public LoginNuevoUsuario() {
        this.setTitle("TypingManiac");
        initCopmonents();
    }
    
    
    public void initCopmonents(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //panelLogin
        fondo = new ImageIcon("pantallalogin1.jpg");
        panelNuevoUsuario = new JPanel();
        panelNuevoUsuario.setLayout(null);
        panelNuevoUsuario.setBounds(0, 0, 300, 450);
        
        panelNuevoUsuario.setBackground(Color.pink);
        this.getContentPane().add(panelNuevoUsuario);
        
        //JLABEL del juego
        fondoo = new JLabel();
        fondoo.setIcon(fondo);
        fondoo.setBounds(0,0,300,450);
        panelNuevoUsuario.add(fondoo);
        //label Login
        labelTitulo = new JLabel("REGISTRO");
        labelTitulo.setBounds(40, 35, 200, 60);
        labelTitulo.setForeground(Color.black);
        labelTitulo.setFont(new Font("Serif", Font.PLAIN, 40));
        fondoo.add(labelTitulo);
        
        //labelNombre
        labelNombre = new JLabel("nombre");
        labelNombre.setBounds(30, 110, 200, 30);
        fondoo.add(labelNombre);
        
        //labelAsterisco
        labelAsterisco = new JLabel("*");
        labelAsterisco.setBounds(78, 110, 200, 30);
        labelAsterisco.setFont(new Font("Serif", Font.PLAIN, 30));
        labelAsterisco.setForeground(Color.red);
        labelAsterisco.setVisible(false);
        fondoo.add(labelAsterisco);
        
        //JtextField
        textNombre = new JTextField();
        textNombre.setBounds(30, 140, 200, 30);
        fondoo.add(textNombre);
        
        //labelSexo
        labelSexo = new JLabel("Seleccione sexo");
        labelSexo.setBounds(40, 200, 200, 30);
        labelSexo.setFont(new Font("Serif", Font.PLAIN, 30));
        fondoo.add(labelSexo);
        
        
        //radioButtom FEMENINO
        radioSexoFemenino = new JRadioButton("femenino",false);
        radioSexoFemenino.setBounds(30, 240, 100, 20);
        fondoo.add(radioSexoFemenino);
        
        //radioButtom MASCULINO
        radioSexoMasculino = new JRadioButton("masculino",false);
        radioSexoMasculino.setBounds(150, 240, 100, 20);
        fondoo.add(radioSexoMasculino);
        
        //agrupando los botones
        grupo1.add(radioSexoFemenino);
        grupo1.add(radioSexoMasculino);
        
        //botonRegistar
        botonRegistrar = new JButton("Registrar");
        botonRegistrar.setBounds(160, 340, 100, 30);
        fondoo.add(botonRegistrar);
        
        //agregando el listener a los botones
        botonRegistrar.addMouseListener(this);
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        cuentaLogin login  = new cuentaLogin();
        if(e.getSource() == botonRegistrar){

            try {
                    BufferedWriter bufer = new BufferedWriter (new FileWriter ("usuarios.txt",true));
                    if(textNombre.getText().equalsIgnoreCase("")){
                        JOptionPane.showMessageDialog(null, " llene los campos seleccionados por un *");
                        labelAsterisco.setVisible(true);
                    }else{
                        bufer.write(textNombre.getText()+"-");
                    }
                    if(radioSexoFemenino.isSelected()){
                         bufer.write("Mujer");

                    }else if(radioSexoMasculino.isSelected()){
                         bufer.write("hombre");
                    }

                    JOptionPane.showMessageDialog(null, "REGISTRO EXITOSO :)");
                    
                    bufer.newLine();
                    bufer.close();
                    
                }catch (IOException e1){
                    
                     JOptionPane.showMessageDialog(null,"Se ha presentado un problema en el registro","Error",2);
                };
                
            login.setBounds(0, 0, 300, 300);
            login.setVisible(true);
            login.setResizable(false);
            login.setLocationRelativeTo(null);
            this.setVisible(false);
                
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
}
